class Produto {
    getPreco() {
      throw new Error("O método abstrato 'getPreco' deve ser implementado.");    }  }
  
  class Camiseta extends Produto {
    getPreco() {
      return 20.00;    }  }
  
  class Capuz extends Produto {
    getPreco() {
      return 40.00;    }  }
  
  class ProdutoFactory {
    createProduto() {
      throw new Error("Abstract method 'createProduto' must be implemented.");    }  }
  
  class CamisetaFactory extends ProdutoFactory {
    createProduto() {
      return new Camiseta();    }  }
  
  class CapuzFactory extends ProdutoFactory {
    createProduto() {
      return new Capuz();    }  }
  
  class Store {
    constructor(factory) {
      this.factory = factory;    }
  
    orderProduto() {
      const produto = this.factory.createProduto();
      const preco = produto.getPreco();
      console.log(`Ordered produto costs ${preco}.`);    }
  }
  
  const camisetaFactory = new CamisetaFactory();
  const capuzFactory = new CapuzFactory();
  
  const store1 = new Store(camisetaFactory);
  store1.orderProduto();
  
  const store2 = new Store(capuzFactory);
  store2.orderProduto();
  
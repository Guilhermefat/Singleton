class Carrinho:
    instance = None

    def __init__(self):
        if Carrinho.instance is None:
            Carrinho.instance = self
            self.items = []
        else:
            raise Exception("Esta Classe é um Singleton")
        
    @staticmethod
    def get_instance():
        if not Carrinho.instance:
            Carrinho()
        return Carrinho.instance
    
    def add_item(self, item):
        self.items.append(item)

    def get_items(self):
        return self.items

class Produto:
    def __init__(self, nome, preco):
        self.nome = nome 
        self.preco = preco

# Utilizando Singleton - criando os carrinhos
Carrinho1 = Carrinho.get_instance()
Carrinho2 = Carrinho.get_instance()

#Adicionar itens no Carrinho 1 
Produto1 = Produto("Camisa", 50.00)
Produto2 = Produto("Calça", 100.00)
Produto3 = Produto("Meia",15.00)
Produto4 = Produto("Tenis",250.00)

Carrinho1.add_item(Produto1)
Carrinho1.add_item(Produto2)
Carrinho1.add_item(Produto3)
Carrinho1.add_item(Produto4)


# Exibindo itens do Carrinhos 1 e 2:


#---------------------------------------------------------------------------------------------
# Cliente


Carrinho1 = Carrinho.get_instance()

print("CARRINHO 01:")
for item in Carrinho1.get_items():
    print(item.nome, "-", item.preco)




# Factory Method
from abc import ABC, abstractmethod

class Produto(ABC):
    @abstractmethod
    def get_preco(self):
        pass

class Camiseta(Produto):
    def get_preco(self):
        return 20.00

class Capuz(Produto):
    def get_preco(self):
        return 40.00

class ProdutoFactory(ABC):
    @abstractmethod
    def create_produto(self):
        pass

class CamisetaFactory(ProdutoFactory):
    def create_produto(self):
        return Camiseta()

class CapuzFactory(ProdutoFactory):
    def create_produto(self):
        return Capuz()

class Store:
    def __init__(self, factory):
        self.factory = factory
    
    def order_produto(self):
        produto = self.factory.create_produto()
        preco = produto.get_preco()
        print(f"Custo do produto encomendado: R${preco}.")

Camiseta_factory = CamisetaFactory()
Capuz_factory = CapuzFactory()

store1 = Store(Camiseta_factory)
store1.order_produto()

store2 = Store(Capuz_factory)
store2.order_produto()

